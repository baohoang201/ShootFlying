using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class score : MonoBehaviour
{
    public int _score;
   public Text txtScore;
    // Start is called before the first frame update
    void Start()
    {
        _score = GetComponent<Dan>().tong;
    }

    // Update is called once per frame
    void Update()
    {
         txtScore.text = "Score: " +_score.ToString();
        
    }
}
