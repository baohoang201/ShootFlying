using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dan : MonoBehaviour
{
     public int speed = 5;
     
     public Text txtScore;
     [SerializeField]
    public int score = 0;
    public int tong;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
           transform.Translate(Vector3.right * speed *Time.deltaTime);
              txtScore = GameObject.Find("Score").GetComponent<Text>();
    }
        
    

     void OnCollisionEnter2D(Collision2D col){
         if(col.gameObject.tag == "sq"){
              score += 1;
              score += tong;
              txtScore.text = "Score: " +score.ToString();
            
             Destroy(col.gameObject);

         }
     }

    
}
