using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Splash : MonoBehaviour
{
    // Start is called before the first frame update
    public static int SceneNumber;
    void Start()
    {
        if(SceneNumber ==0){
            StartCoroutine(  ChangeScene());
          
        }
    }

    IEnumerator ChangeScene(){
            yield return new WaitForSeconds(4);
            SceneManager.LoadScene(1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
