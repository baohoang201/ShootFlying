using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundController : MonoBehaviour
{
    // Start is called before the first frame update
   public float speed = 0.2f;
    float offset;
    SpriteRenderer sprite;
  
    void Start()
    {
           sprite = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
         offset+= Time.deltaTime * speed;
        sprite.material.SetTextureOffset("_MainTex", new Vector2(offset, 0)); //di chuyen theo X
        
    }
}
