using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    public int jump = 5;
    private Rigidbody2D rb;
    public GameObject dan;
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)){

            Vector3 vector3 = transform.position;
            vector3.x = vector3.x +2;
             gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,jump );
              Instantiate(dan,vector3, Quaternion.identity);
        }
    }

    void OnCollisionEnter2D(Collision2D col){
        if(col.gameObject.tag == "sq"){
            SceneManager.LoadScene(3);
            Destroy(gameObject);
           
        }

    }
    
  

}
