using System;
using UnityEngine;

namespace UnityEditor.U2D.Animation
{
    internal interface IBoneSelection : ITransformSelection<BoneCache> {}
}
